import React, { useState } from 'react';
import { Location } from '../types';

interface ReportScreenProps {
  location: Location | null;
  onReportSent: () => void;
  onBack: () => void;
}

const SendIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m22 2-7 20-4-9-9-4Z" /><path d="M22 2 11 13" /></svg>
);
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>
);
const BackIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m15 18-6-6 6-6"/></svg>
);

const ReportScreen: React.FC<ReportScreenProps> = ({ location, onReportSent, onBack }) => {
  const [errorType, setErrorType] = useState('Rua inexistente');
  const [observation, setObservation] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would be sent to a backend like Firebase
    console.log({
      tipoErro: errorType,
      descricao: observation,
      latitude: location?.latitude,
      longitude: location?.longitude,
      data: new Date().toISOString(),
      usuario: 'DefaultUser', // Placeholder for authenticated user
    });
    setIsSent(true);
    onReportSent();
  };
  
  if (isSent) {
      return (
          <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 text-center animate-fade-in">
              <div className="flex justify-center mb-4">
                  <CheckCircleIcon className="w-16 h-16 text-green-500"/>
              </div>
              <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Relatório Enviado!</h2>
              <p className="text-slate-600 dark:text-slate-300">Obrigado pela sua contribuição.</p>
          </div>
      )
  }

  return (
    <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 animate-fade-in-up">
       <div className="relative mb-6 text-center">
            <button onClick={onBack} className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors">
                <BackIcon className="w-6 h-6"/>
            </button>
            <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Reportar Erro</h2>
        </div>
      
      {location && (
        <div className="mb-4 p-3 bg-slate-100 dark:bg-slate-700 rounded-lg text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">
                Localização: {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
            </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="errorType" className="block mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">Tipo de Erro</label>
          <select id="errorType" value={errorType} onChange={(e) => setErrorType(e.target.value)} className="bg-slate-50 border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option>Rua inexistente</option>
            <option>Nome errado</option>
            <option>Erro de rota</option>
          </select>
        </div>
        <div>
          <label htmlFor="observation" className="block mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">Descrição do Erro</label>
          <textarea id="observation" rows={4} value={observation} onChange={(e) => setObservation(e.target.value)} className="block p-2.5 w-full text-sm text-slate-900 bg-slate-50 rounded-lg border border-slate-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-slate-400 dark:text-white" placeholder="Descreva o problema encontrado..."></textarea>
        </div>
        <button type="submit" className="w-full flex items-center justify-center bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-4 focus:ring-green-300 dark:focus:ring-green-800 transition-all duration-300">
          <SendIcon className="mr-2 h-5 w-5" />
          Enviar Relatório
        </button>
      </form>
    </div>
  );
};

export default ReportScreen;
