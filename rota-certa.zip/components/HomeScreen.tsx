import React from 'react';
import { Screen } from '../types';

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void;
}

const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M10 17h4V5H2v12h3" /><path d="M20 17h2v-3.34a4 4 0 0 0-1.17-2.83L19 9h-5v8h6Z" /><path d="M14 17.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5" /><path d="M5 17.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5" /></svg>
);

const MapPinIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
);
const PackageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M16.5 9.4a4.5 4.5 0 1 1-9 0a4.5 4.5 0 0 1 9 0Z"/><path d="M12 15.6a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Z"/><path d="M21 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><path d="M3 3h18v12a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/></svg>
);
const AlertTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>
);
const HistoryIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
);

const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigate }) => {
  const menuItems = [
    { label: 'Iniciar Navegação', icon: MapPinIcon, screen: Screen.Map, color: 'blue' },
    { label: 'Minhas Entregas', icon: PackageIcon, screen: Screen.Deliveries, color: 'purple' },
    { label: 'Reportar Erro', icon: AlertTriangleIcon, screen: Screen.Report, color: 'red' },
    { label: 'Histórico', icon: HistoryIcon, screen: Screen.History, color: 'gray' },
  ];

  return (
    <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 text-center animate-fade-in">
      <div className="flex justify-center items-center mb-6">
        <div className="bg-blue-600 text-white p-4 rounded-full">
            <TruckIcon className="w-10 h-10"/>
        </div>
      </div>
      <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-2">Rota Certa</h1>
      <p className="text-slate-600 dark:text-slate-300 mb-8">Seu assistente de entregas inteligente.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {menuItems.map((item) => (
          <button
            key={item.label}
            onClick={() => onNavigate(item.screen)}
            className={`flex flex-col items-center justify-center p-4 rounded-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4
              bg-${item.color}-100 dark:bg-slate-700 hover:bg-${item.color}-200 dark:hover:bg-slate-600
              text-${item.color}-600 dark:text-${item.color}-300
              focus:ring-${item.color}-300 dark:focus:ring-${item.color}-800`}
          >
            <item.icon className="w-8 h-8 mb-2" />
            <span className="font-semibold text-sm">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default HomeScreen;
