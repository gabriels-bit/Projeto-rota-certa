import React, { useState, useEffect, useRef } from 'react';

// Fix: Add a global declaration for the google object to resolve TypeScript errors.
declare const google: any;

interface MapScreenProps {
  onReportError: () => void;
  onBack: () => void;
}

interface RouteInfo {
    distance: string;
    time: string;
}

const BackIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m15 18-6-6 6-6"/></svg>
);
const NavigationIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
);
const AlertTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4" /><path d="M12 17h.01" /></svg>
);
const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
);

const DeliveryScreen: React.FC<MapScreenProps> = ({ onReportError, onBack }) => {
    const [destination, setDestination] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);

    const mapRef = useRef<HTMLDivElement>(null);
    // Fix: Use google namespace for types, which is now available due to the global declaration.
    const mapInstanceRef = useRef<google.maps.Map | null>(null);
    const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
    const directionsServiceRef = useRef<google.maps.DirectionsService | null>(null);
    const userLocationRef = useRef<google.maps.LatLng | null>(null);

    useEffect(() => {
        const apiKey = process.env.API_KEY;
        if (!apiKey) {
            setError("Chave de API do Google Maps não encontrada.");
            return;
        }

        const initializeMap = () => {
            if (!mapRef.current) return;

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude,
                    };
                    // Fix: Use `google` instead of `window.google`.
                    userLocationRef.current = new google.maps.LatLng(userLocation.lat, userLocation.lng);

                    // Fix: Use `google` instead of `window.google`.
                    const map = new google.maps.Map(mapRef.current!, {
                        center: userLocation,
                        zoom: 15,
                        disableDefaultUI: true,
                        styles: [ // Adding a subtle dark mode style for the map
                            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
                            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
                            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
                            { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                            { featureType: "poi", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                            { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#263c3f" }] },
                            { featureType: "poi.park", elementType: "labels.text.fill", stylers: [{ color: "#6b9a76" }] },
                            { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
                            { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
                            { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
                            { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#746855" }] },
                            { featureType: "road.highway", elementType: "geometry.stroke", stylers: [{ color: "#1f2835" }] },
                            { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#f3d19c" }] },
                            { featureType: "transit", elementType: "geometry", stylers: [{ color: "#2f3948" }] },
                            { featureType: "transit.station", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                            { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] },
                            { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#515c6d" }] },
                            { featureType: "water", elementType: "labels.text.stroke", stylers: [{ color: "#17263c" }] },
                          ]
                    });
                    mapInstanceRef.current = map;
                    
                    // Fix: Use `google` instead of `window.google`.
                    directionsServiceRef.current = new google.maps.DirectionsService();
                    // Fix: Use `google` instead of `window.google`.
                    directionsRendererRef.current = new google.maps.DirectionsRenderer({ suppressMarkers: true });
                    directionsRendererRef.current.setMap(map);

                    // Fix: Use `google` instead of `window.google`.
                    new google.maps.Marker({
                        position: userLocation,
                        map: map,
                        title: "Sua localização",
                        icon: {
                            path: google.maps.SymbolPath.CIRCLE,
                            scale: 8,
                            fillColor: "#4285F4",
                            fillOpacity: 1,
                            strokeColor: "white",
                            strokeWeight: 2,
                        },
                    });
                },
                (err) => {
                    setError(`Erro ao obter localização: ${err.message}`);
                }, { enableHighAccuracy: true }
            );
        };
        
        const loadGoogleMapsScript = () => {
            // Fix: Check for `google` in a way that doesn't cause a ReferenceError and is TypeScript-friendly.
            if (typeof google !== 'undefined' && google.maps) {
                initializeMap();
                return;
            }
            const scriptId = "google-maps-script";
            if (document.getElementById(scriptId)) return;

            const script = document.createElement('script');
            script.id = scriptId;
            script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=routes,places`;
            script.async = true;
            script.defer = true;
            document.head.appendChild(script);
            script.onload = initializeMap;
            script.onerror = () => setError("Não foi possível carregar o mapa. Verifique sua conexão.");
        };

        loadGoogleMapsScript();

    }, []);

    const handleTraceRoute = () => {
        if (!destination) {
            setError("Por favor, insira um destino.");
            return;
        }
        if (!directionsServiceRef.current || !directionsRendererRef.current || !userLocationRef.current) {
            setError("Serviço de mapas não está pronto. Tente novamente em alguns instantes.");
            return;
        }
        setError(null);
        setLoading(true);
        setRouteInfo(null);
        
        // Fix: Use google namespace for types, which is now available due to the global declaration.
        const request: google.maps.DirectionsRequest = {
            origin: userLocationRef.current,
            destination: destination,
            // Fix: Use `google` instead of `window.google`.
            travelMode: google.maps.TravelMode.DRIVING,
        };

        directionsServiceRef.current.route(request, (result, status) => {
            setLoading(false);
            // Fix: Use `google` instead of `window.google`.
            if (status === google.maps.DirectionsStatus.OK && result) {
                directionsRendererRef.current!.setDirections(result);
                const leg = result.routes[0].legs[0];
                if (leg.distance && leg.duration) {
                  setRouteInfo({
                      distance: leg.distance.text,
                      time: leg.duration.text,
                  });
                }
            } else {
                setError(`Não foi possível encontrar a rota: ${status}`);
                setRouteInfo(null);
                directionsRendererRef.current!.setDirections({routes: []}); // Clear previous route
            }
        });
    };

  return (
    <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 animate-fade-in-up">
        <div className="relative mb-6 text-center">
            <button onClick={onBack} className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors">
                <BackIcon className="w-6 h-6"/>
            </button>
            <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Navegação</h2>
        </div>
        
        <div className="space-y-4">
            <div>
              <label htmlFor="destination" className="block mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">Destino</label>
              <input type="text" id="destination" value={destination} onChange={(e) => setDestination(e.target.value)} className="bg-slate-50 border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-slate-400 dark:text-white" placeholder="Digite o endereço de destino..."/>
            </div>
            {error && <p className="text-sm text-red-500 text-center">{error}</p>}
            <button
              onClick={handleTraceRoute}
              disabled={loading || !destination}
              className="w-full flex items-center justify-center bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800 transition-all duration-300 disabled:bg-blue-400 dark:disabled:bg-blue-800 disabled:cursor-not-allowed"
            >
              {loading ? <LoadingSpinner /> : <NavigationIcon className="mr-2 h-5 w-5" />}
              {loading ? 'Traçando...' : 'Traçar Rota'}
            </button>
        </div>
        
        <div className="mt-6 relative">
            <div ref={mapRef} className="h-80 w-full bg-slate-200 dark:bg-slate-700 rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-600">
                {!mapInstanceRef.current && (
                    <div className="flex items-center justify-center h-full text-slate-500 dark:text-slate-400">
                        Carregando mapa...
                    </div>
                )}
            </div>
            {routeInfo && (
                <div className="absolute bottom-2 left-2 right-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm p-3 rounded-lg text-center shadow-lg">
                    <p className="text-md font-semibold text-slate-800 dark:text-slate-100">
                        <span className="font-bold">Distância:</span> {routeInfo.distance} | <span className="font-bold">Tempo:</span> {routeInfo.time}
                    </p>
                </div>
            )}
        </div>


      <div className="mt-6">
        <button
          onClick={onReportError}
          className="w-full flex items-center justify-center bg-red-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-red-700 focus:outline-none focus:ring-4 focus:ring-red-300 dark:focus:ring-red-800 transition-all duration-300"
        >
          <AlertTriangleIcon className="mr-2 h-5 w-5" />
          Reportar Erro
        </button>
      </div>
    </div>
  );
};

export default DeliveryScreen;