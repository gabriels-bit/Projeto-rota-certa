import React, { useState, useCallback } from 'react';
import { Screen, Location } from './types';
import HomeScreen from './components/HomeScreen';
import DeliveryScreen from './components/DeliveryScreen'; // Note: This is now the Map Screen
import ReportScreen from './components/ReportScreen';

// --- Icon Components ---
const PackageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M16.5 9.4a4.5 4.5 0 1 1-9 0a4.5 4.5 0 0 1 9 0Z"/><path d="M12 15.6a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Z"/><path d="M21 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><path d="M3 3h18v12a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/></svg>
);

const HistoryIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
);

const BackIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m15 18-6-6 6-6"/></svg>
);

// --- New Screen Components ---

const DeliveriesScreen: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    return (
        <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 animate-fade-in-up">
            <div className="relative mb-6 text-center">
                <button onClick={onBack} className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors">
                    <BackIcon className="w-6 h-6"/>
                </button>
                <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Minhas Entregas</h2>
            </div>
            <div className="space-y-6">
                <div>
                  <label htmlFor="customerName" className="block mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">Nome do Cliente</label>
                  <input type="text" id="customerName" className="bg-slate-50 border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-slate-400 dark:text-white" placeholder="Ex: João da Silva"/>
                </div>
                <div>
                  <label htmlFor="address" className="block mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">Endereço de Entrega</label>
                  <input type="text" id="address" className="bg-slate-50 border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-slate-400 dark:text-white" placeholder="Ex: Av. Paulista, 1000, São Paulo - SP"/>
                </div>
            </div>
        </div>
    );
};

const HistoryScreen: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    return (
        <div className="bg-white dark:bg-slate-800 shadow-2xl rounded-2xl p-8 animate-fade-in-up text-center">
            <div className="relative mb-6">
                <button onClick={onBack} className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors">
                    <BackIcon className="w-6 h-6"/>
                </button>
                <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Histórico</h2>
            </div>
            <div className="flex flex-col items-center justify-center h-48 bg-slate-100 dark:bg-slate-700 rounded-lg">
                <HistoryIcon className="w-16 h-16 text-slate-400 dark:text-slate-500 mb-4"/>
                <p className="text-slate-600 dark:text-slate-300">O histórico de entregas aparecerá aqui.</p>
            </div>
        </div>
    );
};


// --- Main App Component ---

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Home);
  const [reportLocation, setReportLocation] = useState<Location | null>(null);

  const navigateTo = useCallback((screen: Screen) => {
    setCurrentScreen(screen);
  }, []);

  const handleReportError = useCallback(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setReportLocation({ latitude: position.coords.latitude, longitude: position.coords.longitude });
        navigateTo(Screen.Report);
      },
      (err) => {
        console.error(err);
        setReportLocation(null); // Proceed without location
        navigateTo(Screen.Report);
      }
    );
  }, [navigateTo]);

  const handleReportSent = useCallback(() => {
    setTimeout(() => {
      navigateTo(Screen.Map);
    }, 2000);
  }, [navigateTo]);


  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.Home:
        return <HomeScreen onNavigate={navigateTo} />;
      case Screen.Map:
        return <DeliveryScreen onReportError={handleReportError} onBack={() => navigateTo(Screen.Home)} />;
      case Screen.Deliveries:
        return <DeliveriesScreen onBack={() => navigateTo(Screen.Home)} />;
      case Screen.Report:
        return <ReportScreen location={reportLocation} onReportSent={handleReportSent} onBack={() => navigateTo(Screen.Home)} />;
      case Screen.History:
        return <HistoryScreen onBack={() => navigateTo(Screen.Home)} />;
      default:
        return <HomeScreen onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-900 font-sans">
      <div className="w-full max-w-md">
        {renderScreen()}
      </div>
    </div>
  );
};

export default App;
