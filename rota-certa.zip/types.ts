export enum Screen {
  Home,
  Map,
  Deliveries,
  Report,
  History,
}

export interface Location {
  latitude: number;
  longitude: number;
}
